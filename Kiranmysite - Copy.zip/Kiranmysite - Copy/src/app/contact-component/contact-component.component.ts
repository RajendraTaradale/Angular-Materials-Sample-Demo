import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormArray, Validators, FormBuilder,ReactiveFormsModule } from '@angular/forms';
import { ValidationService } from "../email-validation-service.service";

import {FirebaseListObservable ,AngularFireDatabase} from 'angularfire2/database';
import {Observable } from 'rxjs/Observable';

@Component({
  selector: 'app-contact-component',
  templateUrl: './contact-component.component.html',
  styleUrls: ['./contact-component.component.css']
})
export class ContactComponentComponent implements OnInit {
userForm: any;
responsekey: any='';
items: FirebaseListObservable<any[]>;
Users: FirebaseListObservable<any[]>;

   constructor(af: AngularFireDatabase,fb: FormBuilder) {
    this.items = af.list('/Items');
    this.Users = af.list('/Users');
    this.userForm = fb.group({
      'name': ['', Validators.required],
      'Subject': ['', Validators.required],
      'Phone': ['', Validators.required],
      'Email': ['', [Validators.required, ValidationService.emailValidator]],
      'Message': ['', [Validators.required, Validators.minLength(10)]]
    });
    
  }
  ngOnInit() {
  }
  saveUser(value: any) {
    this.Users.push([{
        Name:value.name,
        Email:value.Email,
        ContanctNo:value.Phone,
        Message:value.Message,
     }]).then((item) => { this.responsekey=item.key  });
      }
}
