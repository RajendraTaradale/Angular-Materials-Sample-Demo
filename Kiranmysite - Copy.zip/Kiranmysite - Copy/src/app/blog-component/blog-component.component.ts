import { Component, OnInit } from '@angular/core';
import { FirebaseListObservable, AngularFireDatabase } from "angularfire2/database";

@Component({
  selector: 'app-blog-component',
  templateUrl: './blog-component.component.html',
  styleUrls: ['./blog-component.component.css']
})
export class BlogComponentComponent implements OnInit {
blog: FirebaseListObservable<any[]>;
  constructor(af: AngularFireDatabase) { 
 this.blog = af.list('/mysite/blog'); }

  ngOnInit() {
  }

}
