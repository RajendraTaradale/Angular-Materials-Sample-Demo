import { Component, OnInit } from '@angular/core';
//import {  } from 'angularfire2';
import {FirebaseListObservable ,AngularFireDatabase} from 'angularfire2/database';
import {Observable } from 'rxjs/Observable';
import { FormControl, FormGroup, FormArray, Validators, FormBuilder,ReactiveFormsModule } from '@angular/forms';
import { ValidationService } from "../email-validation-service.service";
// import {} from '';

@Component({
  selector: 'app-data-samples',
  templateUrl: './data-samples.component.html',
  styleUrls: ['./data-samples.component.css']
})
export class DataSamplesComponent implements OnInit {
userForm: any;
  items: FirebaseListObservable<any[]>;
  Users: FirebaseListObservable<any[]>;
  constructor(af: AngularFireDatabase,fb: FormBuilder) {
    this.items = af.list('/Items');
    this.Users = af.list('/Users');
    this.userForm = fb.group({
      'name': ['', Validators.required],
      'Subject': ['', Validators.required],
      'Phone': ['', Validators.required],
      'Email': ['', [Validators.required, ValidationService.emailValidator]],
      'Message': ['', [Validators.required, Validators.minLength(10)]]
    });
    
  }


  saveUser(value: any) {
    this.Users.push([{
        Name:value.name,
        Email:value.Email,
        ContanctNo:value.Phone,
        Message:value.Message,
     }]).then((item) => { alert(item.key); });
}

  ngOnInit() {
  }

}
