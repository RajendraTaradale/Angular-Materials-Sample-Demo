import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule} from '@angular/router';
import {appRoutes} from './app.route';
import {ControlMessagesComponent} from './control-message.service';
import {ValidationService} from './email-validation-service.service';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';

import { Location, LocationStrategy, HashLocationStrategy} from '@angular/common';
import { AppComponent } from './app.component';
import { HomeComponentComponent } from './home-component/home-component.component';
import { AboutmeComponentComponent } from './aboutme-component/aboutme-component.component';
import { AboutworkComponentComponent } from './aboutwork-component/aboutwork-component.component';
import { BlogComponentComponent } from './blog-component/blog-component.component';
import { ContactComponentComponent } from './contact-component/contact-component.component';

import { AngularFireModule } from 'angularfire2';
import { DataSamplesComponent } from './data-samples/data-samples.component';
import {AngularFireDatabaseModule} from 'angularfire2/database';
// Must export the config
export const firebaseConfig = {
      apiKey: "AIzaSyDC-qrP8HQzELMMQ3eT1_OzsFmwGOxfx2k",
    authDomain: "kirandb-9c49c.firebaseapp.com",
    databaseURL: "https://kirandb-9c49c.firebaseio.com",
    projectId: "kirandb-9c49c",
    storageBucket: "kirandb-9c49c.appspot.com",
    messagingSenderId: "589546262585"
};

@NgModule({
  declarations: [
    AppComponent,
    HomeComponentComponent,
    AboutmeComponentComponent,
    AboutworkComponentComponent,
    BlogComponentComponent,
    ContactComponentComponent,
    ControlMessagesComponent,
    DataSamplesComponent
  ],
  imports: [
    RouterModule.forRoot(appRoutes, { useHash: true }),
    BrowserModule,ReactiveFormsModule,
    FormsModule
    ,AngularFireModule.initializeApp(firebaseConfig),AngularFireDatabaseModule
  ],
  providers: [ValidationService],
  bootstrap: [AppComponent]
})
export class AppModule { }
