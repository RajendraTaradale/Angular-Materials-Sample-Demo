import { Component, OnInit } from '@angular/core';
import { FirebaseListObservable, AngularFireDatabase } from "angularfire2/database";

@Component({
  selector: 'app-aboutwork-component',
  templateUrl: './aboutwork-component.component.html',
  styleUrls: ['./aboutwork-component.component.css']
})
export class AboutworkComponentComponent implements OnInit {
work: FirebaseListObservable<any[]>;
  constructor(af: AngularFireDatabase) { 
 this.work = af.list('/mysite/work'); }

  ngOnInit() {
  }

}
