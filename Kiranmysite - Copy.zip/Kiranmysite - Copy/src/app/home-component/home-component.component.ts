import { Component, OnInit } from '@angular/core';
import { FirebaseListObservable, AngularFireDatabase } from "angularfire2/database";

@Component({
  selector: 'app-home-component',
  templateUrl: './home-component.component.html',
  styleUrls: ['./home-component.component.css']
})
export class HomeComponentComponent {
homedata: FirebaseListObservable<any[]>;
fullname:any
jobtitle:any
email:any
addess:any
phoneno:any
  constructor(af: AngularFireDatabase) {
    this.homedata = af.list('/mysite/home');
    this.homedata.forEach(item => {
    this.fullname=item[2].$value+" "+item[3].$value;
    this.jobtitle=item[5].$value;
    this.email=item[1].$value;
    this.addess=item[0].$value;
    this.phoneno=item[4].$value;
    });
    
   } 
  }  
