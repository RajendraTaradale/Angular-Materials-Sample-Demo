import { Component, OnInit } from '@angular/core';
import { FirebaseListObservable, AngularFireDatabase } from "angularfire2/database";

@Component({
  selector: 'app-aboutme-component',
  templateUrl: './aboutme-component.component.html',
  styleUrls: ['./aboutme-component.component.css']
})
export class AboutmeComponentComponent  {
aboutme: FirebaseListObservable<any[]>;
skill: FirebaseListObservable<any[]>;
list: string[] = [];
descrOne:any;
descrTwo:any;

  constructor(af: AngularFireDatabase) { 
 this.aboutme = af.list('/mysite/aboutme');
this.aboutme.forEach(item => {
    this.descrOne=item[0].$value;
    this.descrTwo=item[1].$value;

});

 this.skill= af.list('mysite/aboutme/Skills');
}
}



