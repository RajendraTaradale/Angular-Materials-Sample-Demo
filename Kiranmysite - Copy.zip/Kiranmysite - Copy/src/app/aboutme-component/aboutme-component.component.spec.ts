import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutmeComponentComponent } from './aboutme-component.component';

describe('AboutmeComponentComponent', () => {
  let component: AboutmeComponentComponent;
  let fixture: ComponentFixture<AboutmeComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AboutmeComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AboutmeComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
