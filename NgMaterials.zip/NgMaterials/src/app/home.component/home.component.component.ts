import { Component, OnInit } from '@angular/core';
import { Address } from '../AddressModel';

import { MdDialog } from '@angular/material';
import { DialogDemoComponent } from '../dialog-demo/dialog-demo.component';

@Component({
  selector: 'my-form',
  templateUrl: './home.component.component.html',
  styleUrls: ['./home.component.component.css'],
  providers:[DialogDemoComponent]
})
export class Home implements OnInit {
address = new Address();
  constructor(public dialog: MdDialog) { }
dialogResult = "";
  ngOnInit() {
  }

  onSubmit() {
    alert("Thanks for submitting! Data: " + JSON.stringify(this.address));
  }
}

