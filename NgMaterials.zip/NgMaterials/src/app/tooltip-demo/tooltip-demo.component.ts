import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tooltip-demo',
  templateUrl: './tooltip-demo.component.html',
  styleUrls: ['./tooltip-demo.component.css']
})
export class TooltipDemoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}