import { Component, OnInit } from '@angular/core';
import {DataSource} from '@angular/cdk/collections';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/observable/of';
@Component({
  selector: 'app-toolbardemo',
  templateUrl: './toolbardemo.component.html',
  styleUrls: ['./toolbardemo.component.css']
})
export class ToolbardemoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}