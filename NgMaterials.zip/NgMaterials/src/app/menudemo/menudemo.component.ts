import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menudemo',
  templateUrl: './menudemo.component.html',
  styleUrls: ['./menudemo.component.css']
})
export class MenudemoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}