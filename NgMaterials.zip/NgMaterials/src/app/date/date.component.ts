import { Component, OnInit } from '@angular/core';

import {DatePickerOptions,DateModel} from 'ng2-datepicker';
@Component({
  selector: 'app-date',
  templateUrl: './date.component.html',
  styleUrls: ['./date.component.css']
})
export class DateComponent  {

  date: DateModel;
  options: DatePickerOptions={
    format:'DD-MM-YYYY',
    todayText:'Oggi',
    style:'big'
  }

  constructor(){
    this.options= new DatePickerOptions();
  }

}
