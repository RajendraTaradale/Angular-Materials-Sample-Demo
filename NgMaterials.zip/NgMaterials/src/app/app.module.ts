import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { FormsModule} from '@angular/forms';

import { AppComponent } from './app.component';

import { BrowserAnimationsModule} from '@angular/platform-browser/animations';
import 'hammerjs';
import { Home } from './home.component/home.component.component';

import {MdInputModule,MdButtonModule} from '@angular/material';
import { MdDialogModule } from '@angular/material';
import { DialogDemoComponent } from './dialog-demo/dialog-demo.component';
import { MyDialogComponent } from './my-dialog/my-dialog.component';



import { MdCardModule,MdMenuModule, MdToolbarModule,MdIconModule,MdSidenavModule } from '@angular/material';
import { MdTooltipModule } from '@angular/material';
import { MdSnackBarModule } from '@angular/material';
import { TooltipDemoComponent } from './tooltip-demo/tooltip-demo.component';
import { SnackbarDemoComponent } from './snackbar-demo/snackbar-demo.component';
import { MenudemoComponent } from './menudemo/menudemo.component';
import { SidenavdemoComponent } from './sidenavdemo/sidenavdemo.component';
import { ToolbardemoComponent } from './toolbardemo/toolbardemo.component';

import { DateAdapter, NativeDateAdapter,MdDatepickerModule } from '@angular/material';
//import { DatepickerModule } from 'angular2-material-datepicker';
import { DateComponent } from './date/date.component'

import {DatePickerModule} from 'ng2-datepicker';
@NgModule({
  declarations: [
    AppComponent,
    Home,DialogDemoComponent,MyDialogComponent, TooltipDemoComponent, 
    SnackbarDemoComponent, MenudemoComponent, SidenavdemoComponent,
     ToolbardemoComponent,
     DateComponent
  ],
  imports: [
    BrowserModule,BrowserAnimationsModule,FormsModule,MdCardModule,MdMenuModule,MdIconModule,
    MdInputModule,MdSidenavModule,MdToolbarModule,MdButtonModule,MdDialogModule,MdTooltipModule,MdCardModule,MdSnackBarModule
    ,MdDatepickerModule,DatePickerModule
  ],
   entryComponents: [
     MyDialogComponent
    ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
